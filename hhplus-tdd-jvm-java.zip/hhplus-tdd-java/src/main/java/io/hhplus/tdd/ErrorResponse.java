package io.hhplus.tdd;

public record ErrorResponse(
        String code,
        String message
) {
}
